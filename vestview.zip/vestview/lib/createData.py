from ymongo import *
ym = YMongo("vestview", "stocks")
ym.add_djia_stocks()