""" File containing Twitter API Keys -- needs to be kept out of github """

consumer_key = 'hcGKopF0crsDNw1uTE77omSbO'
consumer_secret = '3vxkNMiWk6MR0q7UEGJEDDc7UZxGnmy4XO7Y0HYpDCTzEbfy22'
access_token = '194596151-TjnOeLTwNY7lNqlRsI3W3yvAZUlh5aubJeXLoPra'
access_secret = 'xuP8HB1VjBmhIRKMzoKi7SR7oHUJkeEhlHS7PO8ojqnOu'